#ifndef KATE_H_
#define KATE_H_

class Receiver {
	string message;
public:
	void receiveMessage(string ss) {message = ss;}
	void printMessage() {cout << "You said: " << message << endl;}
};
#endif /* KATE_H_ */
