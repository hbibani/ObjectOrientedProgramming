#ifndef JONE_H_
#define JONE_H_

class Sender {
	string message;
public:
	void setMessage();
	string getMessage() {return message;}
};

void Sender::setMessage() {
	string ss;
	cout << "Sender says:";
	getline(cin, ss);
	message = ss;
}
#endif /* JONE_H_ */
